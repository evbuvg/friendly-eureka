// ============================================
// SERAPHIM'S CAKES - Interactive JavaScript
// ============================================

// Wait for page to fully load
document.addEventListener('DOMContentLoaded', function() {

    // ==========================================
    // 1. ORDER NOW BUTTON - WhatsApp Order
    // ==========================================
    const orderBtn = document.querySelector('button');
    
    if (orderBtn) {
        orderBtn.addEventListener('click', function() {
            // Your WhatsApp number (with country code)
            const phone = '2349150440465';
            const message = 'Hello Seraphim\'s Cakes! I would like to place an order.';
            const whatsappUrl = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
            
            // Open WhatsApp
            window.open(whatsappUrl, '_blank');
        });
    }

    // ==========================================
    // 2. MENU ITEMS - Click to show details
    // ==========================================
    const menuItems = document.querySelectorAll('li');
    
    const cakeDetails = {
        'Chocolate Cakes': 'Rich, moist chocolate layers with ganache frosting - ₦15,000',
        'Vanilla Cakes': 'Classic vanilla sponge with buttercream - ₦12,000',
        'Red Velvet Cakes': 'Velvety red layers with cream cheese frosting - ₦18,000',
        'Strawberry Cakes': 'Fresh strawberry filling with whipped cream - ₦16,000',
        'Fruit Cakes': 'Mixed fruits and nuts, perfect for celebrations - ₦20,000'
    };

    menuItems.forEach(function(item) {
        item.addEventListener('click', function() {
            const cakeName = item.textContent.trim();
            const detail = cakeDetails[cakeName];
            
            if (detail) {
                // Remove any existing detail
                const existing = item.querySelector('.cake-detail');
                if (existing) {
                    existing.remove();
                    return;
                }
                
                // Add detail text
                const detailDiv = document.createElement('div');
                detailDiv.className = 'cake-detail';
                detailDiv.style.cssText = `
                    margin-top: 8px;
                    padding: 10px;
                    background: #0f3460;
                    border-radius: 6px;
                    font-size: 0.9rem;
                    color: #f4a261;
                `;
                detailDiv.textContent = detail;
                item.appendChild(detailDiv);
            }
        });
    });

    // ==========================================
    // 3. SMOOTH SCROLLING (if you add nav links)
    // ==========================================
    document.querySelectorAll('a[href^="#"]').forEach(function(anchor) {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });

    // ==========================================
    // 4. ANIMATION ON SCROLL
    // ==========================================
    const observerOptions = {
        threshold: 0.1
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(function(entry) {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    // Observe all sections
    document.querySelectorAll('h2, p, ul').forEach(function(el) {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'all 0.6s ease-out';
        observer.observe(el);
    });

    // ==========================================
    // 5. CURRENT YEAR IN FOOTER (if you add one)
    // ==========================================
    const yearSpans = document.querySelectorAll('.current-year');
    yearSpans.forEach(function(span) {
        span.textContent = new Date().getFullYear();
    });

    // ==========================================
    // 6. CONFETTI EFFECT ON BUTTON HOVER
    // ==========================================
    orderBtn.addEventListener('mouseenter', function() {
        createConfetti();
    });

    function createConfetti() {
        const colors = ['#f4a261', '#e76f51', '#e9c46a', '#2a9d8f'];
        
        for (let i = 0; i < 10; i++) {
            const confetti = document.createElement('div');
            confetti.style.cssText = `
                position: fixed;
                width: 6px;
                height: 6px;
                background: ${colors[Math.floor(Math.random() * colors.length)]};
                border-radius: 50%;
                pointer-events: none;
                z-index: 9999;
                left: ${orderBtn.getBoundingClientRect().left + orderBtn.offsetWidth / 2}px;
                top: ${orderBtn.getBoundingClientRect().top}px;
            `;
            document.body.appendChild(confetti);

            // Animate falling
            const angle = (Math.random() - 0.5) * 100;
            const duration = 1000 + Math.random() * 1000;
            
            confetti.animate([
                { transform: 'translate(0, 0) scale(1)', opacity: 1 },
                { transform: `translate(${angle}px, -80px) scale(0)`, opacity: 0 }
            ], {
                duration: duration,
                easing: 'ease-out'
            }).onfinish = function() {
                confetti.remove();
            };
        }
    }

    // ==========================================
    // 7. WELCOME MESSAGE (first visit only)
    // ==========================================
    if (!localStorage.getItem('visited')) {
        setTimeout(function() {
            alert('🎂 Welcome to Seraphim\'s Cakes! Check out our delicious menu below.');
            localStorage.setItem('visited', 'true');
        }, 1000);
    }

    console.log('🎂 Seraphim\'s Cakes website loaded successfully!');

});
const cakeDetails = {
    'Chocolate Cakes': 'Rich chocolate layers with ganache. Serves 8-10 people.',
    'Vanilla Cakes': 'Classic vanilla sponge with buttercream. Serves 6-8 people.',
    'Red Velvet Cakes': 'Velvety red with cream cheese frosting. Serves 8-10 people.',
    'Strawberry Cakes': 'Fresh strawberry filling with whipped cream. Serves 6-8 people.',
    'Fruit Cakes': 'Mixed fruits and nuts. Perfect for weddings. Serves 10-12 people.'
};
